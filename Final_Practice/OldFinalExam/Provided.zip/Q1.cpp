//Provided code - 12/14/21
#include <iostream>
#include <string>
using namespace std;

class Superhero
{
	public:
	
	Superhero(int np)
	{
		this->numPowers = np;
	}
	
	int numPowers;
		
	protected:
	double strength;
	
	private: 
	int iq;
	
};

//Add Ironman class here with public inheritance from Superhero
//Only one new private member variable: string id
//Default iq = 200, strength = 400, id = "Tony Stark", numPowers = 5


//Add iq_finder here - Non-Member function
//Returns a superhero id


//Add iq_setter here - Non-Member function
//Sets a superhero id


//Add id_finder here - Non-Member function
//Returns a Ironman id

//Only uncomment lines and fix typos
int main()
{
	cout << "Superhero simulator 1.0 running..." << endl;

	int np = 5;
	Superhero superhero1(np);
	cout << "Number of Powers = " << superhero1.numPowers << endl;
	
	//Fix typos - nothing else
	/*
	supefrhero1.set_strength(45.9);
	cout << "Strength = " << superhero1.get_strength << endl;
	*/
	
	//No typos in this block
	/*
	iq_setter(&superhero1, 100);
	cout << "IQ  = " << iq_finder(superhero1) << endl;
	*/
	
	//Fix typos - nothing else
	/*
	Ironman im;
	cout << "Ironman IQ = " << iq_finder(im) << end;
	cout << "Ironman Strength = " << im.get_strength() << endl;
	couft << "Ironman Identity = " << id_finder(iz) << endl;
	cout << "Ironman Number of Powers = " << im.numPowers << endl;
	*/
	
	return 0;
}
  


