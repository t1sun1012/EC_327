//Provided code - 12/14/21
#include <iostream>
#include <string>

using namespace std;

class Videogame
{
	public:
	Videogame() { }
	Videogame(int c)
	{
		cheatcode = c;
	}
	
	string get_character()
	{
		return "None";
	}
	
	void set_highscore(int){};
	int get_highscore(){};
	
	
	protected:
		int highscore;
		
	private:
		int cheatcode;


};

//Add DonkeyKong class here
//get_character method should return "Jumpman"



//DO NOT CHANGE THIS FUNCTION
//Just uncomment the lines back in at the end
void printEnding(Videogame *v)
{
	//cout << "The ending score for "<< v->get_character() << " is " << v->highscore << endl;
	//cout << "The cheat code was " << v->cheatcode << endl;
}

int main()
{
  
  cout << "Q2 running..." << endl;
  
  //Just fix typos
  /*
  Videogame *vg1 = new CrankyKong();
  cout << "VG1 character = " << vg1.get_character() >> endl;
  vg1->set_highscore(100000);
  cout << "VG1 High Score = " << vg1->get_highscore << endl;
  */
  
  /*
  //Three total lines of code you need to add
  1. Make a new DonkeyKong pointer on the heap with the value of 8675309 as the cheatcode
  2. Use that pointer to set the high score of the object to 100
  3. Call printEnding with this object
  */
  
  return 0;
 }

