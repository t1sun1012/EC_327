//Provided 12/14/21
#include <exception>
#include <iostream>
#include <typeinfo>
using namespace std;

class Student
{
	public:
	
	Student()
	{
		studying = 0;
		partying = 0;
		
	}
	
	//Add static member variable here; don't forget to initialize it somewhere...
	
	int studying;
	int partying;
	
	void changeStudyCount()
	{
		studying++;
	}
	
	
	void changePartyCount()
	{ 	
		partying++;
	}
	
		//Add destructor here
		//Output for the destructor
		//cout << "Student deleted. " << objects << " objects left." << endl;
	
};

//Put PartyException here. It needs to be derived from exception.

//This is the body. You just need to wrap it in the definition header
/*
	public:
		Student *sPtr;
		
		PartyException(Student *s)
		{
			cout << this->what() << ": ";
			sPtr = s;
		}
*/


//Add ENGMajor here
//Put this in the destructor: cout << "ENGMajor deleted. " << objects << " objects left." << endl;
//changePartyCount() should just throw a PartyException(this)



//DON'T MODIFY
void party(Student *s)
{
	s->changePartyCount();
	cout << typeid(s).name() << "  was partying" << endl;
	return;
}

//DON'T MODIFY
void study(Student *s)
{
	s->changeStudyCount();
	cout << typeid(s).name() << "  was studying" << endl;
	return;
}

void saturdayNightPlans(Student *s)
{
	//Don't change the cout
	cout << "Saturday night plans: ";
	
	/*
	If the argument to the function is a Student you should use that as the argument to the party method
	If the argument to the function is a ENGMajor you should use that as the argument to the study method
	*/
	
	return;
}

int main()
{

	cout << "Q3 running..." << endl;

	//NO TYPOS - make sure this works
	/*
	Student *s = new Student();
	ENGMajor *e = new ENGMajor();
	
	saturdayNightPlans(s);
	saturdayNightPlans(e);
	
	cout << "Later in the week: ";
	try{
		party(s);
		party(e);
	}
	catch (PartyException ex)
	{
		cout << typeid((*ex.sPtr)).name() << " can't party. Too much work to do!" << endl;
	}

	cout << "Party Count #1 = " << s->partying << endl; 
	cout << "Party Count #2 = " << e->partying << endl; 
	
	cout << "Study Count #1 = " << s->studying << endl; 
	cout << "Study Count #2 = " << e->studying << endl; 
	
	s=e;
	delete s;
	*/
	return 0;
}
