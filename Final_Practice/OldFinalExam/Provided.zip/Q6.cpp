//Provided 12/14/21
#include <iostream>
#include <exception>
using namespace std;


int main()
{

  cout << "Q4 running..." << endl;

  return 0;
}
  
 
 /*
//Multiple sample outputs
 
Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 1
Invalid Entry
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 44
Invalid Entry
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 2
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 13
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 10
Bust with a sum of 23


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 2
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 4
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 6
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 8
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 11
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 14
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 17
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Blackjack


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 11
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 12
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 13
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 14
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 7
Blackjack

Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 3
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 5
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 16
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 4
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 4
Bust with a sum of 24


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 11
Sum is 10
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 12
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 13
Bust with a sum of 30

Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 13
Sum is 10
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Blackjack


 */
  