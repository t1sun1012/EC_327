#include <iostream>
#include <string>
using namespace std;

class Superhero
{
	public:
	
	Superhero(int np)
	{
		this->numPowers = np;
	}
	
	int numPowers;
	
	friend double iq_finder (Superhero);
	friend void iq_setter(Superhero *, int);
	friend class Ironman;
	
	void set_strength(double s)
	{
		strength = s;
	}
	
	double get_strength()
	{
		return strength;
	}
	
	protected:
	double strength;
	
	private: 
	int iq;
	
};

class Ironman:public Superhero
{
	public:
	Ironman():Superhero(5)
	{
		iq = 200;
		strength = 400;
		id = "Tony Stark";
	}
	
	friend double iq_finder(Superhero);
	friend string id_finder(Ironman);

	private:
		string id;
};

double iq_finder(Superhero s)
{
	return s.iq;
}

void iq_setter(Superhero *s, int iq)
{
	s->iq = iq;
	return;
}

string id_finder(Ironman i)
{
	return i.id; 
}

int main()
{
	cout << "Superhero simulator 1.0 running..." << endl;

	int np = 5;
	Superhero superhero1(np);
	cout << "Number of Powers = " << superhero1.numPowers << endl;
	
	superhero1.set_strength(45.9);
	cout << "Strength = " << superhero1.get_strength() << endl;
	
	iq_setter(&superhero1, 100);
	cout << "IQ  = " << iq_finder(superhero1) << endl;
	
	Ironman im;
	cout << "Ironman IQ = " << iq_finder(im) << endl;
	cout << "Ironman Strength = " << im.get_strength() << endl;
	cout << "Ironman Identity = " << id_finder(im) << endl;
	cout << "Ironman Number of Powers = " << im.numPowers << endl;
	
	return 0;
}
  


