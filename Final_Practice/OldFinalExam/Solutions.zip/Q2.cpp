#include <iostream>
#include <string>

using namespace std;

class Videogame
{
	public:
	Videogame() { }
	Videogame(int c)
	{
		cheatcode = c;
	}
	
	virtual string get_character()
	{
		return "None";
	}
	
	virtual void set_highscore(int){};
	virtual int get_highscore(){};
	
	friend void printEnding(Videogame *);
	
	protected:
		int highscore;
		
	private:
		int cheatcode;


};

class DonkeyKong:public Videogame
{
	public:
	DonkeyKong(){ }
	
	DonkeyKong(int c):Videogame(c)
	{ }

	string get_character()
	{
		return "Jumpman";
	}
	
	void set_highscore(int s)
	{
		highscore = s;
	}
	
	int get_highscore()
	{
		return highscore;
	}
	

};

void printEnding(Videogame *v)
{
	cout << "The ending score for "<< v->get_character() << " is " << v->highscore << endl;
	cout << "The cheat code was " << v->cheatcode << endl;
}

int main()
{
  
  cout << "Q2 running..." << endl;
  
  Videogame *vg1 = new DonkeyKong();
  cout << "VG1 character = " << vg1->get_character() << endl;
  vg1->set_highscore(100000);
  cout << "VG1 High Score = " << vg1->get_highscore() << endl;
  
  DonkeyKong *dk1 = new DonkeyKong(8675309);
  dk1->set_highscore(100);
  printEnding(dk1);
  
  return 0;
 }

