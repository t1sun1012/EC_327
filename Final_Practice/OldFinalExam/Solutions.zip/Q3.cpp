#include <exception>
#include <iostream>
#include <typeinfo>
using namespace std;

class Student
{
	public:
	
	Student()
	{
		studying = 0;
		partying = 0;
		objects++;
	}
	
	static int objects;
	int studying;
	int partying;
	
	void changeStudyCount()
	{
		studying++;
	}
	
	//Remove this virtual from provided to see if students can make this a polymorphic class
	virtual void changePartyCount()
	{ 	
		partying++;
	}
	
	virtual ~Student()
	{
		objects--;
		cout << "Student deleted. " << objects << " objects left." << endl;
	}
	
};

int Student::objects = 0;

class PartyException:public exception
{
	public:
		Student *sPtr;
		
		PartyException(Student *s)
		{
			cout << this->what() << ": ";
			sPtr = s;
		}
};

class ENGMajor:public Student
{
	public:
	void changePartyCount()
	{
		throw PartyException(this);
	}
	
	~ENGMajor()
	{
		cout << "ENGMajor deleted. " << objects << " objects left." << endl;
	}
};


void party(Student *s)
{
	s->changePartyCount();
	cout << typeid(s).name() << "  was partying" << endl;
	return;
}

void study(Student *s)
{
	s->changeStudyCount();
	cout << typeid(s).name() << "  was studying" << endl;
	return;
}

void saturdayNightPlans(Student *s)
{
	
	cout << "Saturday night plans: ";
	ENGMajor *eptr = dynamic_cast<ENGMajor*>(s);
	
	if(eptr != NULL)
	{
		study(eptr);
		return ;
	}
	
	else if(s != NULL)
	{
		party(s);
		return;
	}
	
	return;
}

int main()
{

	cout << "Q3 running..." << endl;

	Student *s = new Student();
	ENGMajor *e = new ENGMajor();
	
	saturdayNightPlans(s);
	saturdayNightPlans(e);
	
	cout << "Later in the week: ";
	try{
		party(s);
		party(e);
	}
	catch (PartyException ex)
	{
		cout << typeid((*ex.sPtr)).name() << " can't party. Too much work to do!" << endl;
	}

	cout << "Party Count #1 = " << s->partying << endl; 
	cout << "Party Count #2 = " << e->partying << endl; 
	
	cout << "Study Count #1 = " << s->studying << endl; 
	cout << "Study Count #2 = " << e->studying << endl; 
	
	s=e;
	delete s;
	
	return 0;
}
