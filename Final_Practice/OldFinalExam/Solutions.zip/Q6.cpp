#include <iostream>
#include <typeinfo>
#include <exception>
using namespace std;

int inputCount[15];

void input(int input)
{
	if(input < 2 || input > 14)
		throw exception();
}

void type(int input)
{
	switch(input)
	{
	case 2:
		inputCount[2]++;
		break;
	case 3:
		inputCount[3]++;
		break;	
	case 4:
		inputCount[4]++;
		break;	
	case 5:
		inputCount[5]++;
		break;
	case 6:
		inputCount[6]++;
		break;
	case 7:
		inputCount[7]++;
		break;
	case 8:
		inputCount[8]++;
		break;
	case 9:
		inputCount[9]++;
		break;
	case 10:
		inputCount[10]++;
		break;
	case 11:
		inputCount[11]++;
		break;
	case 12:
		inputCount[12]++;
		break;
	case 13:
		inputCount[13]++;
		break;
	case 14:
		inputCount[14]++;
		break;		
	default:
		break;
	}
	
	if(inputCount[input] > 4)
		throw exception();
}


int main()
{

  cout << "Q4 running..." << endl;
  
  for(int i=0; i<15; i++)
	inputCount[i] = 0;
  
  int card;
  bool valid = true;
  int sum = 0;
  bool cont = true;
  
  while (cont)
  {
	  cout << "Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: ";
	  cin >> card;
	  try
		{
			input(card);
		}
		catch (exception e)
		{
			cout << "Invalid Entry" << endl;
			valid = false;
		}
		
		try
		{
			type(card);
		}
		catch (exception e)
		{
			cout << "Ran out of that card type" << endl;
			valid = false;
		}
		
		if(valid)
		{
			if(card == 11 || card == 12 || card == 13)
				card = 10;
			else if (card == 14 && sum <= 10)
				card = 11;
			else if (card == 14 && sum >10)
				card = 1;
			
			sum = sum+card;
			
			if (sum == 21){
				cout << "Blackjack" << endl;
				cont = false;
			}
			else if (sum >21)
			{
				cout << "Bust with a sum of " << sum << endl;
				cont = false;
			}
			else
				cout << "Sum is " << sum << endl;
			
		}
		valid = true;
	}
	
	return 0;
 }
 
 /*
//Three sample outputs
 
Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 1
Invalid Entry
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 44
Invalid Entry
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 2
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 13
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 10
Bust with a sum of 23


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 2
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 4
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 6
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 8
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 11
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 14
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 17
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Blackjack


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 11
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 12
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 13
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 14
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Ran out of that card type
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 7
Blackjack

Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 3
Sum is 3
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 2
Sum is 5
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Sum is 16
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 4
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 4
Bust with a sum of 24


Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 11
Sum is 10
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 12
Sum is 20
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 13
Bust with a sum of 30

Q4 running...
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 13
Sum is 10
Input a card; 2-10, 11=Jack, 12=Queen, 13=King, 14=ACE: 14
Blackjack


 */
  