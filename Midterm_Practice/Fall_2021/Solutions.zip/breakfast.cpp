#include <iostream>
#include <fstream>
using namespace std;

extern const int PANCAKES;
extern const int FRENCHTOAST;
extern const int WAFFLES;
extern const int FRUITPLATE;

int* getBreakfastOrders(const int count)
{
	
	int *breakfastArray = new int[count];
	for(int i=0; i< count; i++)
	{
		cout << "Order #" << i << " is?: ";
		cin >> breakfastArray[i];
	}
	
	return breakfastArray;
}

char* processBreakfastFile(int *orders, const int orderCount)
{
	char *filename = new char;
	filename = (char*) "Orders.txt";
	ofstream outputFile;
	outputFile.open(filename);
	outputFile.clear();
	for (int i=0; i<orderCount; i++)
	{
		 switch(orders[i])
		  {
			case 1:  outputFile << "Pancakes" << endl; 
				break;
			case 2:  outputFile << "FrenchToast" << endl; 
				break;
			case 3:  outputFile << "Waffles" << endl;   
				break;
			case 4:  outputFile << "FruitPlate" << endl;  
				break;
			default:
			  cout << "Error processing breakfast. There is no " << orders[i] << endl;
		  }
		
	}
	outputFile.close();
	return filename;
}

