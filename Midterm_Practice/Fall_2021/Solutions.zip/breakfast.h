//Add the function prototype for getBreakfastOrders
int* getBreakfastOrders(const int);

//Add the function prototype for processBreakfastFile
char* processBreakfastFile(int *, const int);
