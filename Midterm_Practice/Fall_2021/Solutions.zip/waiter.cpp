#include <fstream>
#include <iostream>
#include <string>
using namespace std;

extern const int PANCAKES;
extern const int FRENCHTOAST;
extern const int WAFFLES;
extern const int FRUITPLATE;


bool orderCheck(char *order)
{
	
	ifstream readFile;
	readFile.open(order);
	string line;
	while(getline (readFile,line))
	{
		cout << "Validating " << line << "..." << endl;
		if (line != "Pancakes" && line != "FrenchToast" && line != "Waffles" && line != "FruitPlate")
		{
			cout << line << " is not a valid breakfast choice!" << endl;
			readFile.close();
			return false;
		}
	}
	readFile.close();
	return true;
}

void orderSum(char *order, double &sum)
{
	cout << "Calculating sum for " << order << "..." << endl;
	ifstream orderFile;
	orderFile.open(order);
	string line;
	while(getline (orderFile,line))
	{
		cout << line << " is processing...." << endl;
		if (line == "Pancakes")
			sum += 5.99;
		if (line == "FrenchToast")
			sum += 7.53;
		if (line == "Waffles")
			sum += 6.99;			
		if (line == "FruitPlate")
			sum += 2.43;
	
	}
	orderFile.close();
	return;
}


double* pay(const double payment, const double bill)
{
	double *pay = new double;
	*pay = payment-bill;
	return pay;
}






