//Uncomment the correct function prototype
//I.E. There is one correct prototype and two incorrect prototype per function

bool orderCheck(char *);

void orderSum(char *, double &);

double* pay(const double , const double);






